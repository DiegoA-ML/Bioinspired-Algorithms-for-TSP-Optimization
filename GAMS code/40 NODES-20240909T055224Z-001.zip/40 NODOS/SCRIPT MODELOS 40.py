import pandas as pd

df = pd.read_excel(r"C:\Users\Sebas\Downloads\matrices_40.xlsx",
                   dtype = str)
counter = 0
idx = 0

while idx < 428:
    counter += 1
    
    filas = slice(idx, idx + 40)
    columnas = slice(0, 41)
    tabla_df = df.iloc[filas, columnas]
    tabla_str = tabla_df.to_string(header=True, index=False, col_space=4, justify='right')
    #print(tabla_df)
    
    idx += 43

    file_path = rf"C:\Users\Sebas\Downloads\MODELOS_GAMS_PROYECTO_FINAL\40 NODOS\GAMS_{counter}.txt"

    with open(file_path, 'w') as file:
        file.write("option optcr = 0.00001;\n\n")
        file.write("Set\n ")
        file.write("i /1*40/ \n ")
        file.write("alias (i,j); \n ")
        file.write("variable z;\n")
        file.write("Binary Variable x(i, j);\n")
        file.write("positive variable u(i);;\n\n")
        file.write("Table\n")
        file.write("c(i,J)\n")
        
        file.write(tabla_str)
        
        file.write(";\n")
        file.write("Equations\n")
        file.write("obj, r1, r2, r3;\n\n")
        file.write("obj.. z=e=sum((i,j),c(i,j)*x(i,j));\n")
        file.write("r1(i).. sum(j, x(i,j))=e=1;\n")
        file.write("r2(j).. sum(i, x(i,j))=e=1;\n")
        file.write("r3(i,j)$((ord(i)>1 and ord(j)>1) and (ord(i)<>ord(j))).. u(i)-u(j)+card(i)*x(i,j)=L=card(i)-1;\n\n")
        file.write("model problemaf /all/;\n")
        file.write("solve problemaf using MIP min z;")
            
         
        print(f"File '{file_path}' created successfully.")

